using System;
using System.Collections.Generic;
using System.Linq;

namespace LibraryManagementSystem
{
    /// <summary>
    /// Класс Библиотека, объединяющий все методы и логику работы
    /// </summary>
    public class Library
    {
        // Задача 11: Статическое название библиотеки
        public static string LibraryName = "Городская центральная библиотека им. А.С. Пушкина";

        // Задача 15: Статический счётчик общего числа книг
        public static int TotalBooks = 0;

        // Коллекции книг и читателей
        private readonly List<Book> _books = new();
        private readonly List<Reader> _readers = new();

        // Задача 2: Метод без параметров. ShowWelcomeMessage(), который выводит приветственное сообщение библиотеки
        public void ShowWelcomeMessage()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("======================================================================");
            Console.WriteLine($"      Добро пожаловать в \"{LibraryName}\"!");
            Console.WriteLine("======================================================================");
            Console.ResetColor();
        }

        // Задача 4: Метод с несколькими параметрами. AddBook(string title, string author, int year)
        public void AddBook(string title, string author, int year)
        {
            if (string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(author))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Ошибка: Название и автор книги не могут быть пустыми!");
                Console.ResetColor();
                return;
            }

            Book newBook = new Book(title.Trim(), author.Trim(), year);
            _books.Add(newBook);

            // Задача 15: Увеличение статического счетчика при добавлении книги
            IncrementTotalBooks();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Книга \"{title}\" (Автор: {author}, {year} г.) успешно добавлена в библиотеку.");
            Console.ResetColor();
        }

        // Перегрузка добавления книги по готовому объекту
        public void AddBook(Book book)
        {
            if (book == null) return;
            _books.Add(book);
            IncrementTotalBooks();
        }

        // Задача 6: Метод с возвращаемым значением. GetBookCount(), который возвращает количество книг в библиотеке
        public int GetBookCount()
        {
            return _books.Count;
        }

        // Задача 7: Метод проверки доступности книги по названию
        public bool IsBookAvailable(string title)
        {
            Book? book = FindBook(title);
            return book != null && book.IsBookAvailable();
        }

        // Задача 8: Метод расчёта. CalculateBookAge(int year), который возвращает возраст книги
        public int CalculateBookAge(int year)
        {
            int currentYear = DateTime.Now.Year;
            return Math.Max(0, currentYear - year);
        }

        // Задача 9: Метод поиска. FindBook(string title), который ищет книгу по названию и возвращает результат поиска
        public Book? FindBook(string title)
        {
            if (string.IsNullOrWhiteSpace(title)) return null;
            return _books.FirstOrDefault(b => b.Title.Equals(title.Trim(), StringComparison.OrdinalIgnoreCase));
        }

        // Задача 10: Метод проверки читателя. IsReaderRegistered(string name), проверяющий наличие читателя в системе
        public bool IsReaderRegistered(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return false;
            string query = name.Trim();
            return _readers.Any(r => 
                r.FullName.Equals(query, StringComparison.OrdinalIgnoreCase) ||
                r.FirstName.Equals(query, StringComparison.OrdinalIgnoreCase));
        }

        // Поиск читателя по имени (возвращает объект или null)
        public Reader? FindReader(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return null;
            string query = name.Trim();
            return _readers.FirstOrDefault(r => 
                r.FullName.Equals(query, StringComparison.OrdinalIgnoreCase) ||
                r.FirstName.Equals(query, StringComparison.OrdinalIgnoreCase));
        }

        // Задача 11: Статический метод. ShowLibraryName(), выводит название библиотеки без создания объекта
        public static void ShowLibraryName()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"[Статический метод] Название библиотеки: \"{LibraryName}\"");
            Console.ResetColor();
        }

        // Задача 12: Нестатический метод. ShowBooks(), выводит список книг конкретного объекта библиотеки
        public void ShowBooks()
        {
            if (_books.Count == 0)
            {
                Console.WriteLine("Библиотечный фонд пока пуст.");
                return;
            }

            Console.WriteLine($"\n--- Список книг библиотеки (Всего: {_books.Count}) ---");
            for (int i = 0; i < _books.Count; i++)
            {
                Console.Write($"{i + 1}. ");
                _books[i].DisplayInfo();
            }
        }

        // Задача 13: Статический метод расчёта. CalculateFine(int overdueDays), рассчитывает штраф за просрочку возврата книги
        public static double CalculateFine(int overdueDays)
        {
            const double FinePerDay = 25.0; // 25 руб. за день просрочки
            if (overdueDays <= 0) return 0.0;
            return overdueDays * FinePerDay;
        }

        // Задача 14: Сравнение методов
        // 14.1 Статический метод: возвращает большее количество книг из двух
        public static int GetMaxBooks(int first, int second)
        {
            return Math.Max(first, second);
        }

        // 14.2 Нестатический метод: возвращает список доступных книг библиотеки
        public List<Book> GetAvailableBooks()
        {
            return _books.Where(b => b.IsAvailable).ToList();
        }

        // Задача 15: Статический счётчик TotalBooks и метод, увеличивающий его значение
        public static void IncrementTotalBooks()
        {
            TotalBooks++;
        }

        // Задача 16: Перегрузка методов SearchBook()
        // 16.1 Поиск по названию
        public List<Book> SearchBook(string title)
        {
            if (string.IsNullOrWhiteSpace(title)) return new List<Book>();
            return _books.Where(b => b.Title.Contains(title.Trim(), StringComparison.OrdinalIgnoreCase)).ToList();
        }

        // 16.2 Поиск по автору (через класс Author)
        public List<Book> SearchBook(Author author)
        {
            if (author == null || string.IsNullOrWhiteSpace(author.Name)) return new List<Book>();
            return _books.Where(b => b.Author.Contains(author.Name.Trim(), StringComparison.OrdinalIgnoreCase)).ToList();
        }

        // Альтернативная перегрузка для поиска по автору со строковым параметром
        public List<Book> SearchBook(string author, bool isSearchByAuthor)
        {
            if (!isSearchByAuthor) return SearchBook(author);
            return SearchBook(new Author(author));
        }

        // 16.3 Поиск по году издания
        public List<Book> SearchBook(int year)
        {
            return _books.Where(b => b.Year == year).ToList();
        }

        // Задача 17: Перегрузка метода AddReader()
        // 17.1 Добавление только по имени
        public void AddReader(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                Console.WriteLine("Ошибка: Имя читателя не может быть пустым.");
                return;
            }
            var reader = new Reader(name.Trim());
            _readers.Add(reader);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Читатель \"{reader.FullName}\" успешно зарегистрирован.");
            Console.ResetColor();
        }

        // 17.2 Добавление по имени и фамилии
        public void AddReader(string firstName, string lastName)
        {
            if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(lastName))
            {
                Console.WriteLine("Ошибка: Имя и фамилия читателя не могут быть пустыми.");
                return;
            }
            var reader = new Reader(firstName.Trim(), lastName.Trim());
            _readers.Add(reader);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Читатель \"{reader.FullName}\" успешно зарегистрирован.");
            Console.ResetColor();
        }

        // 17.3 Добавление по имени и номеру телефона
        public void AddReader(string name, long phoneNumber)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                Console.WriteLine("Ошибка: Имя читателя не может быть пустым.");
                return;
            }
            var reader = new Reader(name.Trim(), phoneNumber);
            _readers.Add(reader);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Читатель \"{reader.FullName}\" (Телефон: {reader.PhoneNumber}) успешно зарегистрирован.");
            Console.ResetColor();
        }

        // Задача 18: Метод с условием. ReturnBook(string title), который возвращает книгу в библиотеку, если она ранее была выдана
        public bool ReturnBook(string title)
        {
            return ReturnBook(title, 0);
        }

        // Задача 19: Рекурсивный метод. CountBooksRecursive(), который рекурсивно подсчитывает количество книг в списке
        public int CountBooksRecursive()
        {
            return CountBooksRecursiveInternal(_books, 0);
        }

        private int CountBooksRecursiveInternal(List<Book> list, int index)
        {
            // Базовый случай: дошли до конца списка
            if (index >= list.Count)
            {
                return 0;
            }
            // Рекурсивный шаг: 1 + количество оставшихся элементов
            return 1 + CountBooksRecursiveInternal(list, index + 1);
        }

        // Задача 20: Метод сортировки. SortBooksByYear(), который сортирует книги по году издания
        public void SortBooksByYear()
        {
            _books.Sort((b1, b2) => b1.Year.CompareTo(b2.Year));
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Книги успешно отсортированы по году издания (по возрастанию).");
            Console.ResetColor();
        }

        // Задача 21: Метод выдачи книги. BorrowBook(string title, string readerName). 
        // Метод проверяет наличие книги и читателя, после чего оформляет выдачу
        public bool BorrowBook(string title, string readerName)
        {
            // 1. Проверка регистрации читателя
            if (!IsReaderRegistered(readerName))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Ошибка: Читатель \"{readerName}\" не зарегистрирован в библиотеке! Сначала зарегистрируйте читателя.");
                Console.ResetColor();
                return false;
            }

            // 2. Поиск книги
            Book? book = FindBook(title);
            if (book == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Ошибка: Книга \"{title}\" не найдена в фонде библиотеки.");
                Console.ResetColor();
                return false;
            }

            // 3. Проверка доступности книги
            if (!book.IsBookAvailable())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Ошибка: Книга \"{book.Title}\" в данный момент уже выдана читателю \"{book.BorrowedBy}\".");
                Console.ResetColor();
                return false;
            }

            // 4. Оформление выдачи
            book.IsAvailable = false;
            book.BorrowedBy = readerName.Trim();
            book.BorrowedDate = DateTime.Now;

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Успешно: Книга \"{book.Title}\" выдана читателю \"{book.BorrowedBy}\".");
            Console.ResetColor();
            return true;
        }

        // Задача 22: Метод возврата книги. ReturnBook() с дополнительной проверкой статуса книги и расчётом штрафа за просрочку
        public bool ReturnBook(string title, int overdueDays)
        {
            Book? book = FindBook(title);
            if (book == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Ошибка: Книга с названием \"{title}\" не найдена в каталоге.");
                Console.ResetColor();
                return false;
            }

            // Проверка статуса книги: была ли она выдана?
            if (book.IsBookAvailable())
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"Предупреждение: Книга \"{book.Title}\" не была выдана, она уже находится в библиотеке!");
                Console.ResetColor();
                return false;
            }

            // Расчет штрафа за просрочку при помощи статического метода Задача 13
            double fine = CalculateFine(overdueDays);
            string previousBorrower = book.BorrowedBy ?? "Неизвестный читатель";

            // Возврат книги в фонд
            book.IsAvailable = true;
            book.BorrowedBy = null;
            book.BorrowedDate = null;

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Книга \"{book.Title}\" успешно возвращена читателем \"{previousBorrower}\".");
            Console.ResetColor();

            if (fine > 0)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($"Внимание: За просрочку на {overdueDays} дн. начислен штраф в размере: {fine:F2} руб.");
                Console.ResetColor();
            }
            else
            {
                Console.WriteLine("Книга возвращена вовремя. Штраф отсутствует.");
            }

            return true;
        }

        // Задача 23: Метод статистики. ShowStatistics(), который выводит:
        // - общее количество книг;
        // - количество доступных книг;
        // - количество выданных книг;
        // - количество зарегистрированных читателей.
        public void ShowStatistics()
        {
            int total = _books.Count;
            int available = _books.Count(b => b.IsAvailable);
            int borrowed = total - available;
            int readersCount = _readers.Count;

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n================ СТАТИСТИКА БИБЛИОТЕКИ ================");
            Console.WriteLine($" Общее количество книг в фонде:       {total}");
            Console.WriteLine($" Количество доступных книг:           {available}");
            Console.WriteLine($" Количество выданных книг:            {borrowed}");
            Console.WriteLine($" Количество зарегистрированных читателей: {readersCount}");
            Console.WriteLine($" Всего добавлено за всё время (static): {TotalBooks}");
            Console.WriteLine("=======================================================");
            Console.ResetColor();
        }

        // Метод вывода всех читателей
        public void ShowReaders()
        {
            if (_readers.Count == 0)
            {
                Console.WriteLine("Зарегистрированных читателей пока нет.");
                return;
            }

            Console.WriteLine($"\n--- Зарегистрированные читатели (Всего: {_readers.Count}) ---");
            for (int i = 0; i < _readers.Count; i++)
            {
                Console.Write($"{i + 1}. ");
                _readers[i].DisplayInfo();
            }
        }

        // Задача 24: Метод главного меню. ShowMenu(), который отображает доступные действия
        public void ShowMenu()
        {
            Console.WriteLine("\n-------------------- ГЛАВНОЕ МЕНЮ --------------------");
            Console.WriteLine("1. Добавить книгу");
            Console.WriteLine("2. Показать все книги");
            Console.WriteLine("3. Найти книгу");
            Console.WriteLine("4. Зарегистрировать читателя");
            Console.WriteLine("5. Выдать книгу");
            Console.WriteLine("6. Вернуть книгу");
            Console.WriteLine("7. Показать статистику");
            Console.WriteLine("8. Автоматическое выполнение всех задач (Задачи 1–25)");
            Console.WriteLine("9. Дополнительно (Сортировка, Рекурсия, Расчет штрафа)");
            Console.WriteLine("0. Завершить программу");
            Console.WriteLine("------------------------------------------------------");
            Console.Write("Выберите пункт меню: ");
        }
    }
}
