using System;

namespace LibraryManagementSystem
{
    /// <summary>
    /// Класс Книга
    /// </summary>
    public class Book
    {
        // Задача 1: Поля Title, Author, Year
        public string Title { get; private set; }
        public string Author { get; private set; }
        public int Year { get; private set; }

        // Дополнительные свойства для статуса книги
        public bool IsAvailable { get; set; } = true;
        public string? BorrowedBy { get; set; } = null;
        public DateTime? BorrowedDate { get; set; } = null;

        public Book(string title, string author, int year)
        {
            Title = title;
            Author = author;
            Year = year;
            IsAvailable = true;
        }

        // Задача 1: Создание метода DisplayInfo(), который выводит информацию о книге
        public void DisplayInfo()
        {
            string status = IsAvailable ? "Доступна" : $"Выдана читателю: {BorrowedBy}";
            Console.WriteLine($"[Книга] \"{Title}\" | Автор: {Author} | Год издания: {Year} | Статус: {status}");
        }

        // Задача 3: Метод с одним параметром. Создайте метод SetTitle(string title), который изменяет название книги
        public void SetTitle(string title)
        {
            if (string.IsNullOrWhiteSpace(title))
            {
                Console.WriteLine("Ошибка: Название книги не может быть пустым.");
                return;
            }
            Title = title;
            Console.WriteLine($"Название книги успешно изменено на: \"{Title}\"");
        }

        // Задача 7: Метод проверки. Реализуйте IsBookAvailable(), который возвращает true, если книга доступна, и false, если она выдана
        public bool IsBookAvailable()
        {
            return IsAvailable;
        }

        // Задача 8: Метод расчёта. Создайте метод CalculateBookAge(int year), который возвращает возраст книги
        public int CalculateBookAge(int currentYear)
        {
            return Math.Max(0, currentYear - Year);
        }

        // Перегрузка без параметров: возраст относительно текущего года системы
        public int CalculateBookAge()
        {
            return CalculateBookAge(DateTime.Now.Year);
        }
    }
}

