namespace LibraryManagementSystem
{
    /// <summary>
    /// Класс Автор для явной типизированной перегрузки методов поиска
    /// </summary>
    public class Author
    {
        public string Name { get; set; }

        public Author(string name)
        {
            Name = name;
        }

        public override string ToString() => Name;
    }
}

