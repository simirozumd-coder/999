(() => {
  "use strict";

  const STORAGE_KEY = "chitalnya-library-v1";
  const currentYear = new Date().getFullYear();
  const seed = {
    books: [
      { id: "book-1", title: "Мастер и Маргарита", author: "Михаил Булгаков", year: 1967, addedAt: 1, available: true, borrowedBy: null },
      { id: "book-2", title: "Маленький принц", author: "Антуан де Сент-Экзюпери", year: 1943, addedAt: 2, available: true, borrowedBy: null },
      { id: "book-3", title: "Норвежский лес", author: "Харуки Мураками", year: 1987, addedAt: 3, available: true, borrowedBy: null },
      { id: "book-4", title: "Гордость и предубеждение", author: "Джейн Остин", year: 1813, addedAt: 4, available: true, borrowedBy: null },
      { id: "book-5", title: "Цветы для Элджернона", author: "Дэниел Киз", year: 1966, addedAt: 5, available: true, borrowedBy: null },
      { id: "book-6", title: "Вино из одуванчиков", author: "Рэй Брэдбери", year: 1957, addedAt: 6, available: true, borrowedBy: null }
    ],
    readers: [
      { id: "reader-1", firstName: "Анна", lastName: "Иванова", phone: "", createdAt: 1 },
      { id: "reader-2", firstName: "Михаил", lastName: "Смирнов", phone: "", createdAt: 2 }
    ],
    nextId: 7
  };
  const state = loadState();
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
  const fullName = (reader) => [reader.firstName, reader.lastName].filter(Boolean).join(" ");

  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
      if (saved && Array.isArray(saved.books) && Array.isArray(saved.readers)) {
        return {
          books: saved.books,
          readers: saved.readers,
          nextId: Number.isInteger(saved.nextId) ? saved.nextId : saved.books.length + saved.readers.length + 1
        };
      }
    } catch (error) {
      console.error("Не удалось прочитать сохранённые данные библиотеки.", error);
    }
    return structuredClone(seed);
  }

  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (error) {
      console.error("Не удалось сохранить данные библиотеки.", error);
      showToast("Не получилось сохранить изменения в браузере.", true);
    }
  }

  function makeId(prefix) {
    return `${prefix}-${state.nextId++}`;
  }

  function recursiveCount(items, index = 0) {
    return index >= items.length ? 0 : 1 + recursiveCount(items, index + 1);
  }

  function titleCaseInitial(title) {
    const first = [...title][0] || "К";
    return escapeHtml(first.toLocaleUpperCase("ru"));
  }

  function bookCover(book) {
    return `<span class="book-cover" aria-hidden="true">${titleCaseInitial(book.title)}</span>`;
  }

  function getReader(readerId) {
    return state.readers.find((reader) => reader.id === readerId);
  }

  function renderStats() {
    const available = state.books.filter((book) => book.available).length;
    $("#stat-total").textContent = recursiveCount(state.books);
    $("#stat-available").textContent = available;
    $("#stat-borrowed").textContent = state.books.length - available;
    $("#stat-readers").textContent = state.readers.length;
    $("#nav-book-count").textContent = state.books.length;
  }

  function renderRecentBooks() {
    const recent = [...state.books].sort((a, b) => b.addedAt - a.addedAt).slice(0, 4);
    $("#recent-books").innerHTML = recent.length
      ? recent.map((book) => `<div class="book-line">${bookCover(book)}<div><div class="book-title">${escapeHtml(book.title)}</div><div class="book-author">${escapeHtml(book.author)}</div></div><span class="book-year">${book.year}</span></div>`).join("")
      : `<div class="empty-state"><span>▤</span><strong>Каталог пока пуст</strong><p>Добавьте первую книгу, чтобы начать.</p></div>`;
    $("#recent-grid").innerHTML = recent.length
      ? recent.map((book) => `<div class="recent-book">${bookCover(book)}<div class="book-info"><div class="book-title">${escapeHtml(book.title)}</div><div class="book-author">${book.year} · ${escapeHtml(book.author)}</div></div></div>`).join("")
      : `<p class="subtitle">Новые книги появятся здесь.</p>`;
  }

  function filteredBooks() {
    const query = $("#book-search").value.trim().toLocaleLowerCase("ru");
    const type = $("#search-type").value;
    const books = state.books.filter((book) => {
      if (!query) return true;
      const titleMatches = book.title.toLocaleLowerCase("ru").includes(query);
      const authorMatches = book.author.toLocaleLowerCase("ru").includes(query);
      const yearMatches = String(book.year).includes(query);
      if (type === "title") return titleMatches;
      if (type === "author") return authorMatches;
      if (type === "year") return yearMatches;
      return titleMatches || authorMatches || yearMatches;
    });
    const sort = $("#book-sort").value;
    if (sort === "year-asc") books.sort((a, b) => a.year - b.year);
    else if (sort === "year-desc") books.sort((a, b) => b.year - a.year);
    else if (sort === "title") books.sort((a, b) => a.title.localeCompare(b.title, "ru"));
    else books.sort((a, b) => b.addedAt - a.addedAt);
    return books;
  }

  function renderBooks() {
    const books = filteredBooks();
    $("#book-rows").innerHTML = books.map((book) => {
      const borrower = book.borrowedBy ? getReader(book.borrowedBy) : null;
      const status = book.available
        ? `<span class="status-badge status-available">Доступна</span>`
        : `<span class="status-badge status-borrowed">У ${escapeHtml(borrower ? fullName(borrower) : "читателя")}</span>`;
      return `<tr>
        <td><div class="table-book">${bookCover(book)}<div>${escapeHtml(book.title)}<div class="table-subtitle">${book.available ? "Книга в фонде" : "Сейчас на руках"}</div></div></div></td>
        <td>${escapeHtml(book.author)}</td>
        <td>${book.year}</td>
        <td>${Math.max(0, currentYear - Number(book.year))} лет</td>
        <td>${status}</td>
        <td class="table-actions"><button type="button" data-rename-book="${escapeHtml(book.id)}" aria-label="Изменить название книги">Изменить</button></td>
      </tr>`;
    }).join("");
    $("#books-empty").classList.toggle("hidden", books.length > 0);
  }

  function renderReaders() {
    $("#reader-grid").innerHTML = state.readers.map((reader) => {
      const borrowedCount = state.books.filter((book) => book.borrowedBy === reader.id).length;
      const initial = escapeHtml([...reader.firstName][0].toLocaleUpperCase("ru"));
      return `<article class="reader-card">
        <div class="reader-top"><div class="reader-avatar">${initial}</div><div><div class="reader-name">${escapeHtml(fullName(reader))}</div><div class="reader-since">Читатель библиотеки</div></div></div>
        <div class="reader-meta"><span>${escapeHtml(reader.phone || "Телефон не указан")}</span><span><strong>${borrowedCount}</strong> книг на руках</span></div>
      </article>`;
    }).join("");
    $("#readers-empty").classList.toggle("hidden", state.readers.length > 0);
  }

  function renderSelects() {
    const availableBooks = state.books.filter((book) => book.available);
    $("#borrow-book").innerHTML = availableBooks.length
      ? availableBooks.map((book) => `<option value="${escapeHtml(book.id)}">${escapeHtml(book.title)} · ${escapeHtml(book.author)}</option>`).join("")
      : `<option value="">Нет доступных книг</option>`;
    $("#borrow-book").disabled = availableBooks.length === 0;
    $("#borrow-reader").innerHTML = state.readers.length
      ? state.readers.map((reader) => `<option value="${escapeHtml(reader.id)}">${escapeHtml(fullName(reader))}</option>`).join("")
      : `<option value="">Сначала зарегистрируйте читателя</option>`;
    $("#borrow-reader").disabled = state.readers.length === 0;
    const borrowedBooks = state.books.filter((book) => !book.available);
    $("#return-book").innerHTML = borrowedBooks.length
      ? borrowedBooks.map((book) => `<option value="${escapeHtml(book.id)}">${escapeHtml(book.title)}${book.borrowedBy ? ` · ${escapeHtml(fullName(getReader(book.borrowedBy) || { firstName: "Читатель" }))}` : ""}</option>`).join("")
      : `<option value="">Нет выданных книг</option>`;
    $("#return-book").disabled = borrowedBooks.length === 0;
  }

  function render() {
    renderStats();
    renderRecentBooks();
    renderBooks();
    renderReaders();
    renderSelects();
  }

  function showToast(message, isError = false) {
    const toast = document.createElement("div");
    toast.className = `toast${isError ? " error" : ""}`;
    toast.textContent = message;
    $("#toast-region").append(toast);
    window.setTimeout(() => toast.remove(), 3500);
  }

  function openDialog(id) {
    renderSelects();
    $(id).showModal();
  }

  function navigate(sectionId) {
    const sectionNames = { overview: "Обзор", books: "Каталог книг", readers: "Читатели", tasks: "25 заданий" };
    const target = document.getElementById(sectionId) ? sectionId : "overview";
    $$(".page-section").forEach((section) => section.classList.toggle("active", section.id === target));
    $$(".nav-link").forEach((link) => link.classList.toggle("active", link.dataset.section === target));
    $("#breadcrumb-current").textContent = sectionNames[target];
    if (location.hash !== `#${target}`) history.replaceState(null, "", `#${target}`);
  }

  const taskGroups = [
    { range: "01—05", title: "Основы методов", tasks: [
      ["01", "Информация о книге", "Название, автор, год и статус книги отображаются в каталоге."],
      ["02", "Приветствие библиотеки", "Приветственный экран встречает посетителя библиотеки."],
      ["03", "Изменение названия", "Кнопка «Изменить» обновляет название книги с проверкой ввода."],
      ["04", "Добавление книги", "Форма принимает название, автора и год издания."],
      ["05", "Вызов методов класса", "Карточки каталога выводят сведения об экземплярах книг."]
    ] },
    { range: "06—10", title: "Поиск и проверки", tasks: [
      ["06", "Количество книг", "Общее число книг вычисляется и показывается в статистике."],
      ["07", "Проверка доступности", "Статус каждой книги обновляется при выдаче и возврате."],
      ["08", "Возраст книги", "Возраст рассчитывается по году издания."],
      ["09", "Поиск книги", "Каталог ищет книги по названию, автору или году."],
      ["10", "Проверка читателя", "Для выдачи выбирается зарегистрированный читатель."]
    ] },
    { range: "11—15", title: "Статические и обычные методы", tasks: [
      ["11", "Название библиотеки", "Название «Читальня» постоянно отображается в интерфейсе."],
      ["12", "Каталог библиотеки", "Таблица показывает книги, принадлежащие текущему каталогу."],
      ["13", "Расчёт штрафа", "Штраф за просрочку — 25 ₽ за каждый день."],
      ["14", "Общие и объектные операции", "Доступность книг и статистика относятся к библиотечному фонду."],
      ["15", "Счётчик фонда", "Счётчики обновляются при добавлении и выдаче книг."]
    ] },
    { range: "16—20", title: "Перегрузка и работа с коллекциями", tasks: [
      ["16", "Поиск по разным параметрам", "В переключателе поиска доступны название, автор и год."],
      ["17", "Регистрация читателя", "Форма принимает имя, фамилию и телефон — все поля, кроме имени, необязательны."],
      ["18", "Условный возврат", "Возврат оформляется только для книги, которая была выдана."],
      ["19", "Рекурсивный подсчёт", "Число книг на экране обзора считается рекурсивным методом."],
      ["20", "Сортировка по году", "Каталог сортируется по году издания и названию."]
    ] },
    { range: "21—25", title: "Полноценная система библиотеки", tasks: [
      ["21", "Выдача книги", "Книга выдаётся зарегистрированному читателю, если она доступна."],
      ["22", "Возврат и штраф", "При возврате рассчитывается штраф за указанное число дней просрочки."],
      ["23", "Статистика", "На главной странице видны книги, доступность, выдачи и читатели."],
      ["24", "Главное меню", "Навигация помогает переключаться между разделами приложения."],
      ["25", "Интеграция проекта", "Каталог, читатели, поиск и операции объединены в одном веб-приложении."]
    ] }
  ];

  function renderTasks() {
    $("#task-groups").innerHTML = taskGroups.map((group, index) => `
      <section class="task-group">
        <div class="task-group-head"><span class="task-group-number">${index + 1}</span><h2>${group.title}</h2><span>${group.range}</span></div>
        <ol class="task-list">${group.tasks.map(([number, title, description]) => `<li><span class="task-check">✓</span><span><strong>${number}. ${title}</strong> — ${description}</span></li>`).join("")}</ol>
      </section>`).join("");
  }

  document.addEventListener("click", (event) => {
    const target = event.target;
    const link = target.closest("[data-section]");
    if (link) {
      event.preventDefault();
      navigate(link.dataset.section);
      return;
    }
    if (target.closest("[data-open-add-book]")) {
      $("#book-form").reset();
      openDialog("#book-dialog");
    } else if (target.closest("[data-open-add-reader]")) {
      $("#reader-form").reset();
      openDialog("#reader-dialog");
    } else if (target.closest("[data-open-borrow]")) {
      openDialog("#borrow-dialog");
    } else if (target.closest("[data-open-return]")) {
      $("#return-form").reset();
      updateFinePreview();
      openDialog("#return-dialog");
    } else if (target.closest("[data-close-dialog]")) {
      target.closest("dialog").close();
    } else if (target.matches("[data-rename-book]")) {
      renameBook(target.dataset.renameBook);
    }
  });

  function renameBook(bookId) {
    const book = state.books.find((item) => item.id === bookId);
    if (!book) return;
    const nextTitle = window.prompt("Введите новое название книги:", book.title);
    if (nextTitle === null) return;
    const cleanTitle = nextTitle.trim();
    if (!cleanTitle) {
      showToast("Название книги не может быть пустым.", true);
      return;
    }
    book.title = cleanTitle;
    saveState();
    render();
    showToast("Название книги обновлено.");
  }

  $("#book-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const title = String(data.get("title")).trim();
    const author = String(data.get("author")).trim();
    const year = Number(data.get("year"));
    if (!title || !author || !Number.isInteger(year) || year < 1 || year > 2100) {
      showToast("Проверьте название, автора и год издания.", true);
      return;
    }
    state.books.push({ id: makeId("book"), title, author, year, addedAt: Date.now(), available: true, borrowedBy: null });
    saveState();
    render();
    event.currentTarget.closest("dialog").close();
    showToast(`«${title}» добавлена в каталог.`);
  });

  $("#reader-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const firstName = String(data.get("firstName")).trim();
    const lastName = String(data.get("lastName")).trim();
    const phone = String(data.get("phone")).trim();
    if (!firstName) {
      showToast("Введите имя читателя.", true);
      return;
    }
    const duplicate = state.readers.some((reader) => fullName(reader).toLocaleLowerCase("ru") === [firstName, lastName].filter(Boolean).join(" ").toLocaleLowerCase("ru"));
    if (duplicate) {
      showToast("Этот читатель уже зарегистрирован.", true);
      return;
    }
    const reader = { id: makeId("reader"), firstName, lastName, phone, createdAt: Date.now() };
    state.readers.push(reader);
    saveState();
    render();
    event.currentTarget.closest("dialog").close();
    showToast(`${fullName(reader)} зарегистрирован(а).`);
  });

  $("#borrow-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const book = state.books.find((item) => item.id === data.get("bookId"));
    const reader = getReader(data.get("readerId"));
    if (!book || !reader || !book.available) {
      showToast("Выберите доступную книгу и зарегистрированного читателя.", true);
      return;
    }
    book.available = false;
    book.borrowedBy = reader.id;
    book.borrowedAt = Date.now();
    saveState();
    render();
    event.currentTarget.closest("dialog").close();
    showToast(`«${book.title}» выдана читателю ${fullName(reader)}.`);
  });

  $("#return-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const book = state.books.find((item) => item.id === data.get("bookId"));
    const overdueDays = Number(data.get("overdueDays"));
    if (!book || book.available || !Number.isInteger(overdueDays) || overdueDays < 0) {
      showToast("Выберите выданную книгу и корректное число дней.", true);
      return;
    }
    const fine = overdueDays * 25;
    const title = book.title;
    book.available = true;
    book.borrowedBy = null;
    delete book.borrowedAt;
    saveState();
    render();
    event.currentTarget.closest("dialog").close();
    showToast(fine ? `«${title}» возвращена. Штраф: ${fine.toLocaleString("ru-RU")} ₽.` : `«${title}» возвращена без штрафа.`);
  });

  function updateFinePreview() {
    const days = Number($("#return-form").elements.overdueDays.value) || 0;
    $("#fine-preview").textContent = `${(days * 25).toLocaleString("ru-RU")} ₽`;
  }

  $("#return-form").elements.overdueDays.addEventListener("input", updateFinePreview);
  $("#book-search").addEventListener("input", renderBooks);
  $("#search-type").addEventListener("change", renderBooks);
  $("#book-sort").addEventListener("change", renderBooks);
  window.addEventListener("hashchange", () => navigate(location.hash.slice(1)));
  window.addEventListener("storage", (event) => {
    if (event.key === STORAGE_KEY) {
      Object.assign(state, loadState());
      render();
    }
  });

  $("#today-label").textContent = new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long", year: "numeric" }).format(new Date());
  renderTasks();
  render();
  navigate(location.hash.slice(1) || "overview");
})();
