using System;

namespace LibraryManagementSystem
{
    /// <summary>
    /// Класс Читатель
    /// </summary>
    public class Reader
    {
        public string FirstName { get; set; }
        public string? LastName { get; set; }
        public string? PhoneNumber { get; set; }

        public string FullName => string.IsNullOrWhiteSpace(LastName) 
            ? FirstName 
            : $"{FirstName} {LastName}";

        public Reader(string firstName)
        {
            FirstName = firstName;
        }

        public Reader(string firstName, string lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }

        public Reader(string firstName, long phoneNumber)
        {
            FirstName = firstName;
            PhoneNumber = phoneNumber.ToString("+7 (###) ###-##-##");
        }

        public Reader(string firstName, string? lastName, string? phoneNumber)
        {
            FirstName = firstName;
            LastName = lastName;
            PhoneNumber = phoneNumber;
        }

        public void DisplayInfo()
        {
            string phoneStr = string.IsNullOrWhiteSpace(PhoneNumber) ? "не указан" : PhoneNumber;
            Console.WriteLine($"[Читатель] {FullName} | Телефон: {phoneStr}");
        }
    }
}

